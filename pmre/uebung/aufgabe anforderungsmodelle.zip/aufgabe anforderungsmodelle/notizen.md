# Berechtigungskonzept

#### Anwender

Feingranulare Berechtigung auf Dokumente und Ordner (read/write). Berechtigungen können auch gruppiert verteilt werden.

#### Administrator

Anwender mit allen Berechtigungen (read/write/execute).

# Weitere Anforderungen

* Administrator kann Berechtigungen vergeben
* Administrator kann Benutzer erstellen
* Administrator kann Benutzer bearbeiten

# Allfällige Fragen

* Was beinhaltet der Aktenplan
* In welchem Land befinden wir uns? (gesetzliche Richtlinien)
* Wie werden die Dokumente genau indexiert?